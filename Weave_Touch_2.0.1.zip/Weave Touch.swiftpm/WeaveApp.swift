// Revolutionary! (again.)

import SwiftUI

struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            BrowserView()
        }
    }
}
