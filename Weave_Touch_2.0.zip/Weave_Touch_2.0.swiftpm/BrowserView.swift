// Made with ❤️ and 🤖 by Ctrl, again. 
// Designed for your iPad, try Weave for the Mac!
// Version 2.0, trust me on this one.

import SwiftUI
import WebKit

struct BrowserView: View {
    @State private var webView = WKWebView()
    @State private var URLString = ""
    @State private var pageTitle = "Weave"
    @State private var faviconImage: Image?
    @State private var userAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3.1 Safari/605.1.15"
    @State private var isRefreshing = false
    
    var body: some View {
        NavigationStack {
            WebView(webView: webView, pageTitle: $pageTitle, URLString: $URLString, faviconImage: $faviconImage, userAgent: $userAgent, isRefreshing: $isRefreshing)
                .navigationTitle(pageTitle)
                .navigationBarTitleDisplayMode(.inline)
                .ignoresSafeArea(.all)
            // Toolbar with keyboard shortcuts and tooltips
                .toolbar (id:"toolbar") {
                    // Back button (cmd + ←)
                    ToolbarItem(id: "back", placement: .topBarLeading) {
                        Button(action: goBack) {
                            Label("Back", systemImage: "chevron.left")
                        }
                        .help("Go back")
                        .keyboardShortcut(KeyEquivalent.leftArrow, modifiers: [.command])
                        .disabled(!webView.canGoBack)
                    }
                    
                    // Forward button (cmd + →)
                    ToolbarItem(id: "forward", placement: .topBarLeading) {
                        Button(action: goForward) {
                            Label("Forward", systemImage: "chevron.right")
                        }
                        .help("Go forward")
                        .keyboardShortcut(KeyEquivalent.rightArrow, modifiers: [.command])
                        .disabled(!webView.canGoForward)
                    }
                    
                    // Address Bar
                    ToolbarItem(id: "address", placement: .principal) {
                        TextField("Search or enter URL", text: $URLString, onCommit: loadURL)
                            .textFieldStyle(DefaultTextFieldStyle())
                            .textContentType(.URL)
                            .autocapitalization(.none)
                            .disableAutocorrection(true)
                            .multilineTextAlignment(.center)
                            .frame(maxWidth: 400)
                            .lineLimit(1) // Limit to 1 line
                            .truncationMode(.tail) // Truncates at the end
                            .onAppear {
                                self.URLString = webView.url?.absoluteString ?? ""
                            }
                            .help("Enter a URL or search term")
                    }
                    
                    // Refresh button (cmd + r)
                    ToolbarItem(id: "refresh", placement: .topBarLeading) {
                        Button(action: refresh) {
                            Label("Refresh", systemImage: "arrow.clockwise")
                        }
                        .help("Refresh this page")
                        .keyboardShortcut("r", modifiers: [.command])
                    }
                    
                    // Favicon and page title display
                    ToolbarItem(id: "favicon", placement: .navigation) {
                        HStack {
                            if let favicon = faviconImage {
                                favicon
                                    .resizable()
                                    .frame(width: 20, height: 20)
                            } else {
                                Image(systemName: "globe.americas.fill")
                                    .resizable()
                                    .frame(width: 18, height: 18)
                                    .fontWeight(.bold)
                            }
                            Text(pageTitle)
                                .fontWeight(.semibold)
                                .frame(maxWidth: 500)
                        }
                    }
                    // Spacer between address bar and Share button chunk
                    ToolbarItem(id: "spacer", placement: .secondaryAction) {
                        Spacer()
                    }
                    
                    // Download button (cmd + shift + d)
                    ToolbarItem(id: "download", placement: .secondaryAction, showsByDefault: true) {
                        Button(action: downloadPage) {
                            Label("Download Page", systemImage: "square.and.arrow.down")
                        }
                        .help("Download page source")
                        .keyboardShortcut("s", modifiers: [.command])
                    }
                    
                    // Copy link button (cmd + shift + c)
                    ToolbarItem(id: "copy", placement: .secondaryAction, showsByDefault: true) {
                        Button(action: {
                            copyURL()
                        }) {
                            Label("Copy Link", systemImage: "doc.on.doc")
                        }
                        .help("Copy current URL to clipboard")
                        .keyboardShortcut("c", modifiers: [.command, .shift])
                    }
                }
                .onAppear {
                    loadURL()
                }
        }
    }
    
    func copyURL() {
        UIPasteboard.general.string = URLString
    }
    
    private func goBack() {
        if webView.canGoBack {
            webView.goBack()
            // Adds extremely slight delay before refreshing page when navigating
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                refresh()
            }
        }
    }
    
    private func goForward() {
        if webView.canGoForward {
            webView.goForward()
            // Adds extremely slight delay before refreshing page when navigating
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                refresh()
            }
        }
    }
    
    private func refresh() {
        webView.reload()
    }
    
    private func loadURL() {
        let trimmedURLString = URLString.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmedURLString.contains(".") {
            // Contains a dot, likely a URL
            if let url = URL(string: addHttpIfNeeded(trimmedURLString)) {
                let request = URLRequest(url: url)
                webView.load(request)
            }
        } else {
            // No dot, treat as search query
            search()
        }
    }
    
    private func search() {
        guard let searchQuery = URLString.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else { return }
        if let searchURL = URL(string: "https://google.com/search?q=\(searchQuery)") {
            let request = URLRequest(url: searchURL)
            webView.load(request)
        }
    }
    
    private func addHttpIfNeeded(_ URLString: String) -> String {
        if URLString.hasPrefix("http://") || URLString.hasPrefix("https://") {
            return URLString
        } else {
            return "https://\(URLString)"
        }
    }
    
    private func downloadPage() {
        webView.evaluateJavaScript("document.URL") { (result, error) in
            if let urlString = result as? String, let url = URL(string: urlString) {
                let downloadTask = URLSession.shared.downloadTask(with: url) { (location, response, error) in
                    guard let location = location else { return }
                    let documentsPath = FileManager.default.urls(for: .downloadsDirectory, in: .userDomainMask)[0]
                    let destinationURL = documentsPath.appendingPathComponent(response?.suggestedFilename ?? url.lastPathComponent)
                    
                    do {
                        try FileManager.default.moveItem(at: location, to: destinationURL)
                        print("File downloaded successfully: \(destinationURL.absoluteString)")
                    } catch {
                        print("Error saving file: \(error)")
                    }
                }
                downloadTask.resume()
            }
        }
    }
}

struct ContentView: View {
    var body: some View {
        NavigationStack {
            BrowserView()
        }
    }
}

struct WebView: UIViewRepresentable {
    let webView: WKWebView
    @Binding var pageTitle: String
    @Binding var URLString: String
    @Binding var faviconImage: Image?
    @Binding var userAgent: String
    @Binding var isRefreshing: Bool
    
    func makeUIView(context: Context) -> WKWebView {
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(context.coordinator, action: #selector(Coordinator.handleRefreshControl(sender:)), for: .valueChanged)
        
        let configuration = WKWebViewConfiguration()
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        configuration.defaultWebpagePreferences.preferredContentMode = .desktop
        webView.navigationDelegate = context.coordinator
        webView.customUserAgent = userAgent
        webView.scrollView.refreshControl = refreshControl
        
        return webView
    }
    
    func updateUIView(_ uiView: WKWebView, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator(webView: webView, pageTitle: $pageTitle, URLString: $URLString, faviconImage: $faviconImage, isRefreshing: $isRefreshing)
    }
    
    class Coordinator: NSObject, WKNavigationDelegate {
        let webView: WKWebView
        @Binding var pageTitle: String
        @Binding var URLString: String
        @Binding var faviconImage: Image?
        @Binding var isRefreshing: Bool
        
        init(webView: WKWebView, pageTitle: Binding<String>, URLString: Binding<String>, faviconImage: Binding<Image?>, isRefreshing: Binding<Bool>) {
            self.webView = webView
            self._pageTitle = pageTitle
            self._URLString = URLString
            self._faviconImage = faviconImage
            self._isRefreshing = isRefreshing
        }
        
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            webView.evaluateJavaScript("document.title") { (result, error) in
                if let title = result as? String {
                    self.pageTitle = title
                    self.URLString = webView.url?.absoluteString ?? ""
                    self.loadFavicon()
                }
            }
        }
        
        private func loadFavicon() {
            let script = """
                var favicon = document.querySelector('link[rel="shortcut icon"]') || document.querySelector('link[rel="icon"]');
                favicon ? favicon.href : null;
            """
            
            webView.evaluateJavaScript(script) { (result, error) in
                if let faviconURLString = result as? String, let faviconURL = URL(string: faviconURLString) {
                    DispatchQueue.main.async {
                        if let data = try? Data(contentsOf: faviconURL) {
                            if let uiImage = UIImage(data: data) {
                                self.faviconImage = Image(uiImage: uiImage)
                            }
                        }
                    }
                } else {
                    DispatchQueue.main.async {
                        self.faviconImage = nil
                    }
                }
            }
        }
        
        // Handle refresh control action
        @objc func handleRefreshControl(sender: UIRefreshControl) {
            isRefreshing = true
            webView.reload()
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                sender.endRefreshing()
                self.isRefreshing = false
            }
        }
    }
}

struct WeaveAppCustom: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

@main
struct Weave: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
