// Made with ❤️ and 🤖 by Ctrl, again.
// Designed for your iPad and iPhone, try Weave for the Mac!
// Version 3.0, trust me on this one.

import SwiftUI
import WebKit

// Initializes BrowserView variables for web view setup
struct BrowserView: View {
    @State private var webView = WKWebView()
    @State private var URLString = ""
    @State private var pageTitle = "Weave"
    @State private var faviconImage: Image?
    @State private var isRefreshing = false
    // All this stuff is to automatically fetch 2 key values to automatically build a user agent, the WebKit version (based on default user agent) and Safari version (based on current OS).
    @State private var userAgent: String = {
        let defaultUserAgent = WKWebView().value(forKey: "userAgent")
        let safariVersion = UIDevice.current.systemVersion
        var webKitVersion = ""
        if let userAgentString = defaultUserAgent as? String {
            if let startIndex = userAgentString.range(of: "AppleWebKit/")?.upperBound {
                let versionSubstring = userAgentString[startIndex...]
                if let endIndex = versionSubstring.firstIndex(of: " ") ?? versionSubstring.firstIndex(of: "/") {
                    webKitVersion = String(versionSubstring[..<endIndex])
                }
            }
        }
        // I would make user agents based on device width, however it seems difficult to do before setting up a view, so this checks device type instead
        if UIDevice.current.userInterfaceIdiom == .phone {
            // iPhone user agent (default + added values)
            return "\(defaultUserAgent ?? "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/621.4.20 (KHTML, like Gecko) Weave/Fallback") Version/\(safariVersion) Safari/\(webKitVersion)"
        } else {
            // iPad/Vision/Catalyst user agent (custom + added values for WebKit and Safari versions)
            return "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/\(webKitVersion) (KHTML, like Gecko) Version/\(safariVersion) Safari/\(webKitVersion)"
        }
    }()
    
    var body: some View {
        GeometryReader { geometry in
            NavigationStack {
                WebView(webView: webView, pageTitle: $pageTitle, URLString: $URLString, faviconImage: $faviconImage, userAgent: $userAgent, isRefreshing: $isRefreshing)
                    // UI initialization for toolbar, gestures, and safe area
                    .navigationTitle(pageTitle)
                    .navigationBarTitleDisplayMode(.inline)
                    .ignoresSafeArea(.all)
                    .gesture(
                        DragGesture().onEnded { gesture in
                            if gesture.translation.width > 100 {
                                goBack()
                            } else if gesture.translation.width < -100 {
                                goForward()
                            }
                        })
                    // Initializes stuff to do when app starts
                    .onAppear {
                        // CSS Style Injection
                        let styleSheet = """
                            var style = document.createElement('style');
                            style.innerHTML = `
                                * {
                                    font-family: -apple-system !important;
                                    letter-spacing: 0px !important;
                                }
                            `;
                            document.head.appendChild(style);
                        """
    
                        // Extremely basic CSS Adblock Injection
                        let adBlockerScript = """
                            var adBlockStyle = document.createElement('style');
                            adBlockStyle.innerHTML = `
                                /* Hide common ad classes */
                                .ad-banner, .ad-wrapper, .ad-container, .ad, .ads, .adsense, .adslot, .ad-badge {
                                    display: none !important;
                                }

                                /* Hide ads from specific URLs */
                                [href*="doubleclick.net"], [href*="googleadservices.com"], [href*="advertising.com"], [src*="adserver.com"] {
                                    display: none !important;
                                }
                            `;
                            document.head.appendChild(adBlockStyle);
                        """
                        let adBlockInject = WKUserScript(source: adBlockerScript, injectionTime: .atDocumentEnd, forMainFrameOnly: false)
                        webView.configuration.userContentController.addUserScript(adBlockInject)
    
                        let CSSInject = WKUserScript(source: styleSheet, injectionTime: .atDocumentEnd, forMainFrameOnly: false)
                        webView.configuration.userContentController.addUserScript(CSSInject)
                        
                        // Loads URL for Google, once all of that's done
                        loadURL()
                    }
                    
                    // Toolbar with keyboard shortcuts and tooltips
                    .toolbar(id: "toolbar") {
                        if geometry.size.width > 700 {
                            // iPad toolbar starts here
                            // Back button (cmd + ←)
                            ToolbarItem(id: "back", placement: .topBarLeading) {
                                Button(action: goBack) {
                                    Label("Back", systemImage: "chevron.left")
                                }
                                .help("Go back")
                                .keyboardShortcut(KeyEquivalent.leftArrow, modifiers: [.command])
                                .disabled(!webView.canGoBack)
                            }
                            
                            // Forward button (cmd + →)
                            ToolbarItem(id: "forward", placement: .topBarLeading) {
                                Button(action: goForward) {
                                    Label("Forward", systemImage: "chevron.right")
                                }
                                .help("Go forward")
                                .keyboardShortcut(KeyEquivalent.rightArrow, modifiers: [.command])
                                .disabled(!webView.canGoForward)
                            }
                            
                            // Address Bar
                            ToolbarItem(id: "address", placement: .principal) {
                                TextField("Search or enter URL", text: $URLString, onCommit: loadURL)
                                    .textFieldStyle(DefaultTextFieldStyle())
                                    // Formatting to make URLs easier to type
                                    .textContentType(.URL) // Sets content type for text
                                    .autocapitalization(.none) // Disables auto capitalization
                                    .disableAutocorrection(true) // Disables auto correct
                                    .multilineTextAlignment(.center) // Centers URL in text box
                                    .frame(minWidth:100, maxWidth: 400) // Limits size of URL
                                    .lineLimit(1) // Limit to 1 line
                                    .truncationMode(.tail) // Truncates at the end
                                    .keyboardType(.webSearch) // Uses URL/search keyboard type
                                    .onAppear {
                                        self.URLString = webView.url?.absoluteString ?? ""
                                    }
                                    .help("Enter a URL or search term")
                                    // Selects all text when address bar is selected
                                    .onReceive(NotificationCenter.default.publisher(for: UITextField.textDidBeginEditingNotification)) { obj in
                                        if let textField = obj.object as? UITextField {
                                            textField.selectedTextRange = textField.textRange(from: textField.beginningOfDocument, to: textField.endOfDocument)
                                        }
                                    }
                            }
                            
                            // Refresh button (cmd + r)
                            ToolbarItem(id: "refresh", placement: .topBarLeading) {
                                Button(action: refresh) {
                                    Label("Refresh", systemImage: "arrow.clockwise")
                                }
                                .help("Refresh this page")
                                .keyboardShortcut("r", modifiers: [.command])
                            }
                            
                            // Favicon and page title display
                            ToolbarItem(id: "header", placement: .navigation) {
                                HStack {
                                    if let favicon = faviconImage {
                                        favicon
                                            .resizable()
                                            .frame(width: 20, height: 20)
                                    } else {
                                        Image(systemName: "globe.americas.fill")
                                            .resizable()
                                            .frame(width: 18, height: 18)
                                            .fontWeight(.bold)
                                    }
                                    Text(pageTitle)
                                        .fontWeight(.semibold)
                                        .frame(maxWidth:80)
                                }
                            }
                            
                            // Spacer between address bar and Share button chunk
                            ToolbarItem(id: "spacer", placement: .secondaryAction) {
                                Spacer()
                            }
                            
                            // Copy link button (cmd + shift + c)
                            ToolbarItem(id: "copy", placement: .secondaryAction, showsByDefault: true) {
                                Button(action: {
                                    copyURL()
                                }) {
                                    Label("Copy Link", systemImage: "doc.on.doc")
                                }
                                .help("Copy current URL to clipboard")
                                .keyboardShortcut("c", modifiers: [.command, .shift])
                            }
                            
                            // Share button (cmd + shift + s) !!! THIS WILL CRASH IN SWIFT PLAYGROUNDS !!!
                            ToolbarItem(id: "share", placement: .secondaryAction, showsByDefault: true) {
                                ShareLink(item: URLString) {
                                    Label("Share", systemImage: "square.and.arrow.up")
                                }
                                .help("Share this page")
                                .keyboardShortcut("s", modifiers: [.command, .shift])
                            }
                        } 
                        
                        else {
                            // iPhone toolbar starts here
                            // Back button (cmd + ←)
                            ToolbarItem(id: "back", placement: .navigation) {
                                Button(action: goBack) {
                                    Label("Back", systemImage: "chevron.left")
                                }
                                .help("Go back")
                                .keyboardShortcut(KeyEquivalent.leftArrow, modifiers: [.command])
                                .disabled(!webView.canGoBack)
                            }

                            // Forward button (cmd + →)
                            ToolbarItem(id: "forward", placement: .navigation) {
                                Button(action: goForward) {
                                    Label("Forward", systemImage: "chevron.right")
                                }
                                .help("Go forward")
                                .keyboardShortcut(KeyEquivalent.rightArrow, modifiers: [.command])
                                .disabled(!webView.canGoForward)
                            }
                            
                            // Address Bar
                            ToolbarItem(id: "address", placement: .principal) {
                                TextField("Search or enter URL", text: $URLString, onCommit: loadURL)
                                    .textFieldStyle(DefaultTextFieldStyle())
                                    // Formatting to make URLs easier to type
                                    .textContentType(.URL) // Sets content type for text
                                    .autocapitalization(.none) // Disables auto capitalization
                                    .disableAutocorrection(true) // Disables auto correct
                                    .multilineTextAlignment(.center) // Centers URL in text box
                                    .frame(maxWidth: 400) // Limits size of URL
                                    .lineLimit(1) // Limit to 1 line
                                    .truncationMode(.tail) // Truncates at the end
                                    .keyboardType(.webSearch) // Uses URL/search keyboard type
                                    .onAppear {
                                        self.URLString = webView.url?.absoluteString ?? ""
                                    }
                                    .help("Enter a URL or search term")
                                    // Selects all text when address bar is selected
                                    .onReceive(NotificationCenter.default.publisher(for: UITextField.textDidBeginEditingNotification)) { obj in
                                        if let textField = obj.object as? UITextField {
                                            textField.selectedTextRange = textField.textRange(from: textField.beginningOfDocument, to: textField.endOfDocument)
                                        }
                                    }
                            }

                            // Refresh button (cmd + r)
                            ToolbarItem(id: "refresh", placement: .secondaryAction) {
                                Button(action: refresh) {
                                    Label("Refresh", systemImage: "arrow.clockwise")
                                }
                                .help("Refresh this page")
                                .keyboardShortcut("r", modifiers: [.command])
                            }

                            // Copy link button (cmd + shift + c)
                            ToolbarItem(id: "copy", placement: .secondaryAction, showsByDefault: true) {
                                Button(action: {
                                    copyURL()
                                }) {
                                    Label("Copy Link", systemImage: "doc.on.doc")
                                }
                                .help("Copy current URL to clipboard")
                                .keyboardShortcut("c", modifiers: [.command, .shift])
                            }
                            
                            // Share button (cmd + shift + s)
                            ToolbarItem(id: "share", placement: .secondaryAction, showsByDefault: true) {
                                ShareLink(item: URLString) {
                                    Label("Share", systemImage: "square.and.arrow.up")
                                }
                                .help("Share this page")
                                .keyboardShortcut("s", modifiers: [.command, .shift])
                            }
                        }
                    }
            }
        }
    }
    
    // Functions for webpage commands
    
    struct ShareSheet: UIViewControllerRepresentable {
        typealias UIViewControllerType = UIActivityViewController

        var sharing: [Any]

        func makeUIViewController(context: UIViewControllerRepresentableContext<ShareSheet>) -> UIActivityViewController {
            UIActivityViewController(activityItems: sharing, applicationActivities: nil)
        }

        func updateUIViewController(_ uiViewController: UIActivityViewController, context: UIViewControllerRepresentableContext<ShareSheet>) {

        }
    }
    
    // Copy current URL to clipboard
    func copyURL() {
        UIPasteboard.general.string = URLString
    }
    
    // Goes back a page and reloads to fetch title and favicon again
    private func goBack() {
        if webView.canGoBack {
            webView.goBack()
            // Adds extremely slight delay before refreshing page when navigating
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                refresh()
            }
        }
    }
    
    // Goes forward a page and reloads to fetch title and favicon again
    private func goForward() {
        if webView.canGoForward {
            webView.goForward()
            // Adds extremely slight delay before refreshing page when navigating
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                refresh()
            }
        }
    }
    
    // Simple refresh function
    private func refresh() {
        webView.reload()
    }
    
    // Verifies URL validity and loads page (or searches, if it's invalid)
    private func loadURL() {
        let trimmedURLString = URLString.trimmingCharacters(in: .whitespacesAndNewlines)
        // Finds final dot in string
        if let lastDotIndex = trimmedURLString.lastIndex(of: ".") {
            let afterLastDotIndex = trimmedURLString.index(after: lastDotIndex)
            // Check if there are characters following the last period
            if afterLastDotIndex < trimmedURLString.endIndex {
                // Characters following the last period, so assume it's a domain
                if let url = URL(string: addHTTPIfNeeded(trimmedURLString)) {
                    let request = URLRequest(url: url)
                    webView.load(request)
                    return
                }
            }
        }
        // No more than 1 character following final period, likely a search query
        search()
    }
    
    // Simple Google search function
    private func search() {
        guard let searchQuery = URLString.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else { return }
        if let searchURL = URL(string: "https://google.com/search?q=\(searchQuery)") {
            let request = URLRequest(url: searchURL)
            webView.load(request)
        }
    }
    
    // Adds https:// for URLs that are valid, but don't have it
    private func addHTTPIfNeeded(_ URLString: String) -> String {
        if URLString.hasPrefix("http://") || URLString.hasPrefix("https://") {
            return URLString
        } else {
            return "https://\(URLString)"
        }
    }
}

struct ContentView: View {
    var body: some View {
        NavigationStack {
            BrowserView()
        }
    }
}

// Random stuff for initializing the actual web view I can't be bothered to comment

struct WebView: UIViewRepresentable {
    let webView: WKWebView
    @Binding var pageTitle: String
    @Binding var URLString: String
    @Binding var faviconImage: Image?
    @Binding var userAgent: String
    @Binding var isRefreshing: Bool
    
    func makeUIView(context: Context) -> WKWebView {
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(context.coordinator, action: #selector(Coordinator.handleRefreshControl(sender:)), for: .valueChanged)
        
        let configuration = WKWebViewConfiguration()
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        configuration.defaultWebpagePreferences.preferredContentMode = .desktop
        webView.navigationDelegate = context.coordinator
        webView.customUserAgent = userAgent
        webView.scrollView.refreshControl = refreshControl
        
        return webView
    }
    
    func updateUIView(_ uiView: WKWebView, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator(webView: webView, pageTitle: $pageTitle, URLString: $URLString, faviconImage: $faviconImage, isRefreshing: $isRefreshing)
    }
    
    class Coordinator: NSObject, WKNavigationDelegate {
        let webView: WKWebView
        @Binding var pageTitle: String
        @Binding var URLString: String
        @Binding var faviconImage: Image?
        @Binding var isRefreshing: Bool
        
        init(webView: WKWebView, pageTitle: Binding<String>, URLString: Binding<String>, faviconImage: Binding<Image?>, isRefreshing: Binding<Bool>) {
            self.webView = webView
            self._pageTitle = pageTitle
            self._URLString = URLString
            self._faviconImage = faviconImage
            self._isRefreshing = isRefreshing
        }
        
        // Injects JavaScript to load page title and pass it to the rest of the code as the pageTitle variable
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            webView.evaluateJavaScript("document.title") { (result, error) in
                if let title = result as? String {
                    self.pageTitle = title
                    self.URLString = webView.url?.absoluteString ?? ""
                    self.loadFavicon()
                }
            }
        }
        
        // Injects JavaScript to load favicon and pass it to the rest of the code as a UIImage
        private func loadFavicon() {
            let script = """
                var favicon = document.querySelector('link[rel="shortcut icon"]') || document.querySelector('link[rel="icon"]');
                favicon ? favicon.href : null;
            """
            
            webView.evaluateJavaScript(script) { (result, error) in
                if let faviconURLString = result as? String, let faviconURL = URL(string: faviconURLString) {
                    DispatchQueue.main.async {
                        if let data = try? Data(contentsOf: faviconURL) {
                            if let uiImage = UIImage(data: data) {
                                self.faviconImage = Image(uiImage: uiImage)
                            }
                        }
                    }
                } else {
                    DispatchQueue.main.async {
                        self.faviconImage = nil
                    }
                }
            }
        }
        
        // Handles pull to refresh controls
        @objc func handleRefreshControl(sender: UIRefreshControl) {
            isRefreshing = true
            webView.reload()
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                sender.endRefreshing()
                self.isRefreshing = false
            }
        }
    }
}

struct WeaveAppCustom: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

@main
struct Weave: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
